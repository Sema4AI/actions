# Template: Minimal

The template is a minimal example of an action. It contains necessary files and follows the required structure, but is not doing anything apart from returning a simple message.

🚀 You can leverage the whole Python ecosystem when creating actions. Sema4.ai provides a bunch of libraries; you can make your own. The sky is the limit.

👉 Check [Action Server](https://github.com/Sema4AI/actions/tree/master/action_server/docs) and [Actions](https://github.com/Sema4AI/actions/tree/master/actions/docs) docs for more information.